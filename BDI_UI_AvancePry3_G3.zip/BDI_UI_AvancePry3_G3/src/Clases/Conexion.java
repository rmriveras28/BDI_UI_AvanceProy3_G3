package Clases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author kevin
 */
public class Conexion {

    public static Connection getConexion() {
        String url = "jdbc:sqlserver://localhost:1433;"
                + "database=PROYECTOSQL;"
                + "user=userSQL;"
                + "password=1234;"
                + "loginTimeout=30;";

        try {
            Connection con = DriverManager.getConnection(url);
            return con;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
            return null;
        }
    }

    public int Login(String usuario, String contraseña) {
        int resultado = 0;
        Connection con = Conexion.getConexion();
        ResultSet rs;
        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM EMPLEADO WHERE USUARIO = '" + usuario + "' AND CONTRASEÑA = '" + contraseña + "'");
            
            rs = ps.executeQuery();
            if(rs.next()){
              JOptionPane.showMessageDialog(null, "Bienvenido");
              resultado = 1;
            }
            else{
                 JOptionPane.showMessageDialog(null, "Problemas con el usuario Y/O contraseña");
                 resultado = 0;
            }
        } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, e.toString());
        }
        return resultado;
    }

}
