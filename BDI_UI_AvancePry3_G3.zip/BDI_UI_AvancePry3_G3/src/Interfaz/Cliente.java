package Interfaz;

import Clases.Conexion;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author kevin
 */
public class Cliente extends javax.swing.JFrame {

    ButtonGroup btnGr;
    private int idAuto, idCliente;

    public Cliente() {
        initComponents();
        this.setLocationRelativeTo(null);
        btnGr = new ButtonGroup();
        txtId.setVisible(false);
        txtPrecio.setVisible(false);
        txtDisponibilidad.setVisible(false);
        cargarTabla();
        cargarTablaAuto();
        btnGr.add(rbMasculino);
        btnGr.add(rbFemenino);
        cargarComboBoxSucursal();
        cargarComboBoxEmpleado();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCliente = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtIdentidad = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtPrimerNombre = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtSegundoNombre = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtPrimerApellido = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtSegundoApellido = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        cbSucursal = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        cbEmpleado = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        txtId = new javax.swing.JTextField();
        rbMasculino = new javax.swing.JRadioButton();
        rbFemenino = new javax.swing.JRadioButton();
        btnLimpiar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblAutom = new javax.swing.JTable();
        txtMarca = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        txtModelo = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        txtDisponibilidad = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();
        btnReporte = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Clientes");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 11, -1, -1));

        tblCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Identidad", "Nombre1", "Nombre2", "Apellido1", "Apellido2", "Sexo", "Direccion", "Email", "Telefono", "devolver vehiculo", "Sucursal", "Marca", "Modelo", "Empleado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblClienteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblCliente);
        if (tblCliente.getColumnModel().getColumnCount() > 0) {
            tblCliente.getColumnModel().getColumn(0).setResizable(false);
            tblCliente.getColumnModel().getColumn(1).setResizable(false);
            tblCliente.getColumnModel().getColumn(2).setResizable(false);
            tblCliente.getColumnModel().getColumn(3).setResizable(false);
            tblCliente.getColumnModel().getColumn(4).setResizable(false);
            tblCliente.getColumnModel().getColumn(5).setResizable(false);
            tblCliente.getColumnModel().getColumn(6).setResizable(false);
            tblCliente.getColumnModel().getColumn(7).setResizable(false);
            tblCliente.getColumnModel().getColumn(8).setResizable(false);
            tblCliente.getColumnModel().getColumn(9).setResizable(false);
            tblCliente.getColumnModel().getColumn(10).setResizable(false);
            tblCliente.getColumnModel().getColumn(11).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 1199, 147));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Identidad:");

        txtIdentidad.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Primer Nombre:");

        txtPrimerNombre.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Segundo Nombre:");

        txtSegundoNombre.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Primer Apellido:");

        txtPrimerApellido.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Segundo Apellido:");

        txtSegundoApellido.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Sexo:");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Direccion:");

        txtDireccion.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("Email:");

        txtEmail.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("Telefono:");

        txtTelefono.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("Fecha devolver vehiculo:");

        txtFecha.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setText("Sucursales:");

        cbSucursal.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setText("Automovil");

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel14.setText("Empleado:");

        cbEmpleado.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        btnGuardar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnModificar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        rbMasculino.setText("Masculino");

        rbFemenino.setText("Femenino");

        btnLimpiar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        tblAutom.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Marca", "Modelo", "Pasajeros", "Disponibilidad", "Precio"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblAutom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblAutomMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblAutom);
        if (tblAutom.getColumnModel().getColumnCount() > 0) {
            tblAutom.getColumnModel().getColumn(0).setResizable(false);
            tblAutom.getColumnModel().getColumn(1).setResizable(false);
            tblAutom.getColumnModel().getColumn(2).setResizable(false);
            tblAutom.getColumnModel().getColumn(3).setResizable(false);
            tblAutom.getColumnModel().getColumn(4).setResizable(false);
            tblAutom.getColumnModel().getColumn(5).setResizable(false);
        }

        txtMarca.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel15.setText("Marca:");

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel16.setText("Modelo:");

        txtModelo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Transaccion");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setText("Factura");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btnRegresar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnRegresar.setText("Regresar");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        btnReporte.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnReporte.setText("Generar Reporte ");
        btnReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReporteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPrimerNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtSegundoNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
                            .addComponent(txtPrimerApellido)
                            .addComponent(txtSegundoApellido))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(jLabel7)
                        .addGap(60, 60, 60)
                        .addComponent(rbMasculino)
                        .addGap(18, 18, 18)
                        .addComponent(rbFemenino)
                        .addGap(0, 271, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel16))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtFecha, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtDireccion)
                                    .addComponent(txtEmail)
                                    .addComponent(txtTelefono)
                                    .addComponent(txtMarca)
                                    .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addComponent(txtDisponibilidad, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(123, 123, 123)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(jLabel14))
                        .addGap(39, 39, 39)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cbSucursal, 0, 196, Short.MAX_VALUE)
                            .addComponent(cbEmpleado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(178, 178, 178))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(63, Short.MAX_VALUE)
                .addComponent(btnReporte)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnGuardar)
                        .addGap(18, 18, 18)
                        .addComponent(btnModificar)
                        .addGap(18, 18, 18)
                        .addComponent(btnLimpiar)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(18, 18, 18)
                        .addComponent(btnRegresar)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(666, 666, 666)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel12)
                    .addComponent(cbSucursal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rbMasculino)
                    .addComponent(rbFemenino))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtPrimerNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14)
                            .addComponent(cbEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel4)
                                .addComponent(txtSegundoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 1, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(txtPrimerApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtSegundoApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(17, 17, 17)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(txtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnGuardar)
                                    .addComponent(btnModificar)
                                    .addComponent(btnLimpiar)
                                    .addComponent(jButton1)
                                    .addComponent(jButton2)
                                    .addComponent(btnRegresar)
                                    .addComponent(btnReporte)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtDisponibilidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 220, -1, -1));

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/style.jpg"))); // NOI18N
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, 800, 210));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/style.jpg"))); // NOI18N
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(-40, -20, 700, 260));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/style.jpg"))); // NOI18N
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, -30, -1, 270));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblClienteMouseClicked
        try {
            int fila = tblCliente.getSelectedRow();
            //primero va el indice de la columna y luego la posicion de la columna
            int id = Integer.parseInt(tblCliente.getValueAt(fila, 0).toString());
            Connection con = Conexion.getConexion();
            PreparedStatement ps;
            ResultSet rs;
            ps = con.prepareStatement("SELECT CL.IDENTIDAD,\n"
                    + "CL.NOMBRE1,\n"
                    + "CL.NOMBRE2,\n"
                    + "CL.APELLIDO1,\n"
                    + "CL.APELLIDO2,\n"
                    + "CL.SEXO,\n"
                    + "CL.DIRECCION,\n"
                    + "CL.EMAIL,\n"
                    + "CL.TELEFONO,\n"
                    + "CL.FECHA_ENTREGA_VEHICULO,\n"
                    + "CL.ID_SUCURSAL,\n"
                    + "A.MARCA,\n"
                    + "A.MODELO,\n"
                    + "G.ID_AGENTE_DE_ALQUILER\n"
                    + "FROM CLIENTE CL\n"
                    + "INNER JOIN AUTOMOVIL A ON CL.ID_AUTOMOVIL = A.ID_AUTOMOVIL\n"
                    + "INNER JOIN AGENTE_DE_ALQUILER G ON CL.ID_AGENTE_DE_ALQUILER = G.ID_AGENTE_DE_ALQUILER\n"
                    + "WHERE ID_CLIENTE=?");
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                txtId.setText(String.valueOf(id));
                txtIdentidad.setText(rs.getString("IDENTIDAD"));
                txtPrimerNombre.setText(rs.getString("NOMBRE1"));
                txtSegundoNombre.setText(rs.getString("NOMBRE2"));
                txtPrimerApellido.setText(rs.getString("APELLIDO1"));
                txtSegundoApellido.setText(rs.getString("APELLIDO2"));
                txtDireccion.setText(rs.getString("DIRECCION"));
                txtEmail.setText(rs.getString("EMAIL"));
                txtTelefono.setText(rs.getString("TELEFONO"));
                txtFecha.setText(rs.getString("FECHA_ENTREGA_VEHICULO"));
                cbSucursal.setSelectedIndex(rs.getInt("ID_SUCURSAL") - 1);
                txtMarca.setText(rs.getString("MARCA"));
                txtModelo.setText(rs.getString("MODELO"));
                cbEmpleado.setSelectedIndex(rs.getInt("ID_AGENTE_DE_ALQUILER") - 1);
                if (rs.getString("SEXO").equals("M")) {
                    rbMasculino.setSelected(true);
                } else if (rs.getString("SEXO").equals("F")) {
                    rbFemenino.setSelected(true);
                }

            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }//GEN-LAST:event_tblClienteMouseClicked

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        String identidad = txtIdentidad.getText();
        String primerNombre = txtPrimerNombre.getText();
        String segundoNombre = txtSegundoNombre.getText();
        String primerApellido = txtPrimerApellido.getText();
        String segundoApellido = txtSegundoApellido.getText();
        String direccion = txtDireccion.getText();
        String email = txtEmail.getText();
        String telefono = txtTelefono.getText();
        String fecha = txtFecha.getText();
        int sucursal = (int) cbSucursal.getSelectedIndex() + 1;
        int empleado = (int) cbEmpleado.getSelectedIndex() + 1;
        String sexo;
        if (rbMasculino.isSelected() == true) {
            sexo = "M";
        } else if (rbFemenino.isSelected() == true) {
            sexo = "F";
        } else {
            sexo = "M";
        }
        if (txtIdentidad.getText().isEmpty() || txtPrimerNombre.getText().isEmpty() || txtSegundoNombre.getText().isEmpty() || txtPrimerApellido.getText().isEmpty() || txtSegundoApellido.getText().isEmpty() || txtMarca.getText().isEmpty() || txtModelo.getText().isEmpty() || txtFecha.getText().isEmpty() || txtDireccion.getText().isEmpty() || txtEmail.getText().isEmpty() || txtTelefono.getText().isEmpty() || rbMasculino.isSelected() == false && rbFemenino.isSelected() == false) {
            JOptionPane.showMessageDialog(null, "No puede dejar ningun campo vacio");
        } else {
            try {
                //para hacer transacciones se necesita la conexion a la base de datos
                Connection con = Conexion.getConexion();
                //para hacer la insercion de un query se necesita un PreparedStatement
                PreparedStatement ps = con.prepareStatement("INSERT INTO CLIENTE (IDENTIDAD, NOMBRE1, NOMBRE2, APELLIDO1, APELLIDO2, SEXO, DIRECCION, EMAIL, TELEFONO, FECHA_ENTREGA_VEHICULO, ID_SUCURSAL, ID_AUTOMOVIL, ID_AGENTE_DE_ALQUILER) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
                //ahora hay que preparar los valores para insertar
                //primero va el indice y luego el valor
                ps.setString(1, identidad);
                ps.setString(2, primerNombre);
                ps.setString(3, segundoNombre);
                ps.setString(4, primerApellido);
                ps.setString(5, segundoApellido);
                ps.setString(6, sexo);
                ps.setString(7, direccion);
                ps.setString(8, email);
                ps.setString(9, telefono);
                ps.setString(10, fecha);
                ps.setInt(11, sucursal);
                ps.setInt(12, idAuto);
                ps.setInt(13, empleado);
                //ahora hay que ejecutar la consulta para eso se usa siempre el la variable de tipo
                //PreparedStatement y usando el metodo executeUpdate
                ps.executeUpdate();
                JOptionPane.showMessageDialog(null, "Registro Guardado");
                obtenerIdCliente();
                cambiarDisponibilidad();

                limpiar();
                cargarTabla();
            }//cierre del try
            catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e.toString());
            }//cierre del cath
        }//cierre del else
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiar();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void cambiarDisponibilidad() {
        String disponibilidad = txtDisponibilidad.getText();
        if (disponibilidad.equals("V")) {
            disponibilidad = "F";
        }
        System.out.println(disponibilidad);
        try {
            //para hacer transacciones se necesita la conexion a la base de datos
            Connection con = Conexion.getConexion();
            //para hacer la insercion de un query se necesita un PreparedStatement
            PreparedStatement ps = con.prepareStatement("UPDATE AUTOMOVIL SET DISPONIBILIDAD=? WHERE ID_AUTOMOVIL =?");
            //ahora hay que preparar los valores para insertar
            //primero va el indice y luego el valor
            ps.setString(1, disponibilidad);
            ps.setInt(2, idAuto);
            //ahora hay que ejecutar la consulta para eso se usa siempre el la variable de tipo
            //PreparedStatement y usando el metodo executeUpdate
            ps.executeUpdate();
            cargarTablaAuto();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }

    private void tblAutoMouseClicked(java.awt.event.MouseEvent evt) {
        try {
            int fila = tblAutom.getSelectedRow();
            //primero va el indice de la columna y luego la posicion de la columna
            idAuto = Integer.parseInt(tblAutom.getValueAt(fila, 0).toString());
            Connection con = Conexion.getConexion();
            PreparedStatement ps;
            ResultSet rs;
            ps = con.prepareStatement("SELECT MARCA, MODELO, PRECIO FROM AUTOMOVIL WHERE ID_AUTOMOVIL=?");
            ps.setInt(1, idAuto);
            rs = ps.executeQuery();
            while (rs.next()) {
                txtId.setText(String.valueOf(idAuto));
                txtMarca.setText(rs.getString("MARCA"));
                txtModelo.setText(rs.getString("MODELO"));
                txtPrecio.setText(rs.getString("PRECIO"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }

    private void obtenerIdCliente() {
        int idCliente = 0;
        ResultSet rs;
        try {
            //para hacer transacciones se necesita la conexion a la base de datos
            Connection con = Conexion.getConexion();
            //para hacer la insercion de un query se necesita un PreparedStatement
            PreparedStatement ps = con.prepareStatement("SELECT TOP 1 ID_CLIENTE FROM CLIENTE ORDER BY ID_CLIENTE DESC");
            rs = ps.executeQuery();
            while (rs.next()) {
                idCliente = rs.getInt(1);
                System.out.println(idCliente);
            }
            insertTransaccion(idCliente);
        }//cierre del try
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }//cierre del catch
    }

    private void insertTransaccion(int idCliente) {
        int voucher = (int) (Math.random() * 1000000000 + 1);
        int precio = Integer.parseInt(txtPrecio.getText());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String fechaComoCadena = sdf.format(new Date());
        System.out.println(fechaComoCadena);
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement("INSERT INTO TRANSACCION (NUMERO_VOUCHER, MONTO, FECHA_EMISION, ID_AUTOMOVIL, ID_CLIENTE) VALUES (?,?,?,?,?)");
            ps.setInt(1, voucher);
            ps.setInt(2, precio);
            ps.setString(3, fechaComoCadena);
            ps.setInt(4, idAuto);
            ps.setInt(5, idCliente);
            ps.executeUpdate();
            obtenerIdTransaccion();
        }//cierre del try
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }//cierre del catch
    }

    private void obtenerIdTransaccion() {
        int idTransaccion = 0;
        ResultSet rs;
        try {
            //para hacer transacciones se necesita la conexion a la base de datos
            Connection con = Conexion.getConexion();
            //para hacer la insercion de un query se necesita un PreparedStatement
            PreparedStatement ps = con.prepareStatement("SELECT TOP 1 ID_TRANSACCION FROM TRANSACCION ORDER BY ID_TRANSACCION DESC");
            rs = ps.executeQuery();
            while (rs.next()) {
                idTransaccion = rs.getInt(1);
                System.out.println(idTransaccion);
            }
            insertFactura(idTransaccion);
        }//cierre del try
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }//cierre del catch
    }

    private void insertFactura(int idTransaccion) {
        int sucursal = (int) cbSucursal.getSelectedIndex() + 1;
        int empleado = (int) cbEmpleado.getSelectedIndex() + 1;
        obtenerIdCliente2();
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement("INSERT INTO FACTURA (ID_SUCURSAL, ID_AGENTE_DE_ALQUILER, ID_TRANSACCION, ID_CLIENTE, ID_AUTOMOVIL) VALUES (?,?,?,?,?)");
            ps.setInt(1, sucursal);
            ps.setInt(2, empleado);
            ps.setInt(3, idTransaccion);
            ps.setInt(4, idCliente);
            ps.setInt(5, idAuto);
            ps.executeUpdate();
        }//cierre del try
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }//cierre del catch
    }

    private void obtenerIdCliente2() {
        idCliente = 0;
        ResultSet rs;
        try {
            //para hacer transacciones se necesita la conexion a la base de datos
            Connection con = Conexion.getConexion();
            //para hacer la insercion de un query se necesita un PreparedStatement
            PreparedStatement ps = con.prepareStatement("SELECT TOP 1 ID_CLIENTE FROM CLIENTE ORDER BY ID_CLIENTE DESC");
            rs = ps.executeQuery();
            while (rs.next()) {
                idCliente = rs.getInt(1);
                System.out.println(idCliente);
            }
        }//cierre del try
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }//cierre del catch
    }

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int id = Integer.parseInt(txtId.getText());
        String identidad = txtIdentidad.getText();
        String primerNombre = txtPrimerNombre.getText();
        String segundoNombre = txtSegundoNombre.getText();
        String primerApellido = txtPrimerApellido.getText();
        String segundoApellido = txtSegundoApellido.getText();
        String direccion = txtDireccion.getText();
        String email = txtEmail.getText();
        String telefono = txtTelefono.getText();
        String fecha = txtFecha.getText();
        int idSucursal = cbSucursal.getSelectedIndex() + 1;
        int idEmpleado = cbEmpleado.getSelectedIndex() + 1;
        String sexo;
        if (rbMasculino.isSelected() == true) {
            sexo = "M";
        } else if (rbFemenino.isSelected() == true) {
            sexo = "F";
        } else {
            sexo = "M";
        }
        try {
            //para hacer transacciones se necesita la conexion a la base de datos
            Connection con = Conexion.getConexion();
            //para hacer la insercion de un query se necesita un PreparedStatement
            PreparedStatement ps = con.prepareStatement("UPDATE CLIENTE SET IDENTIDAD=?, NOMBRE1=?, NOMBRE2=?, APELLIDO1=?, APELLIDO2=?, SEXO=?, DIRECCION=?, EMAIL=?, TELEFONO=?, FECHA_ENTREGA_VEHICULO=?, ID_SUCURSAL=?, ID_AUTOMOVIL=?, ID_AGENTE_DE_ALQUILER=? WHERE ID_CLIENTE=?");
            //ahora hay que preparar los valores para insertar
            //primero va el indice y luego el valor
            ps.setString(1, identidad);
            ps.setString(2, primerNombre);
            ps.setString(3, segundoNombre);
            ps.setString(4, primerApellido);
            ps.setString(5, segundoApellido);
            ps.setString(6, sexo);
            ps.setString(7, direccion);
            ps.setString(8, email);
            ps.setString(9, telefono);
            ps.setString(10, fecha);
            ps.setInt(11, idSucursal);
            ps.setInt(12, idAuto);
            ps.setInt(13, idEmpleado);
            ps.setInt(14, id);
            //ahora hay que ejecutar la consulta para eso se usa siempre el la variable de tipo
            //PreparedStatement y usando el metodo executeUpdate
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro Modificado");
            limpiar();
            cargarTabla();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void tblAutomMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblAutomMouseClicked
        try {
            int fila = tblAutom.getSelectedRow();
            //primero va el indice de la columna y luego la posicion de la columna
            idAuto = Integer.parseInt(tblAutom.getValueAt(fila, 0).toString());
            Connection con = Conexion.getConexion();
            PreparedStatement ps;
            ResultSet rs;
            ps = con.prepareStatement("SELECT MARCA, MODELO, PRECIO, DISPONIBILIDAD FROM AUTOMOVIL WHERE ID_AUTOMOVIL=?");
            ps.setInt(1, idAuto);
            rs = ps.executeQuery();
            while (rs.next()) {
                txtId.setText(String.valueOf(idAuto));
                txtMarca.setText(rs.getString("MARCA"));
                txtModelo.setText(rs.getString("MODELO"));
                txtPrecio.setText(rs.getString("PRECIO"));
                txtDisponibilidad.setText(rs.getString("DISPONIBILIDAD"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }//GEN-LAST:event_tblAutomMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Transaccion t = new Transaccion();
        t.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Factura f = new Factura();
        f.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        LoginAgenteDeAlquiler l = new LoginAgenteDeAlquiler();
        l.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void btnReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReporteActionPerformed
        Document documento = new Document();

        String ruta = System.getProperty("user.home");
        try {
            PdfWriter.getInstance(documento, new FileOutputStream(ruta + "/Desktop/Reporte-Agente de alquiler.pdf"));

            documento.open();
            PdfPTable tabla = new PdfPTable(7);
            tabla.addCell("Primer Nombre Del Cliente");
            tabla.addCell("Primer Apellido Del Cliente");
            tabla.addCell("Marca Del Vehiculo");
            tabla.addCell("Modelo Del Vehiculo");
            tabla.addCell("Fecha Entrega Vehiculo");
            tabla.addCell("Primer Nombre Del Empleado");
            tabla.addCell("Primer Apellido Del Empleado");

            try {
                Connection con = Conexion.getConexion();
                PreparedStatement ps = con.prepareStatement("SELECT CL.NOMBRE1,\n"
                        + "CL.APELLIDO1,\n"
                        + "A.MARCA,\n"
                        + "A.MODELO,\n"
                        + "CL.FECHA_ENTREGA_VEHICULO,\n"
                        + "E.NOMBRE1,\n"
                        + "E.APELLIDO1\n"
                        + "FROM	CLIENTE CL\n"
                        + "INNER JOIN AUTOMOVIL A ON CL.ID_AUTOMOVIL = A.ID_AUTOMOVIL\n"
                        + "INNER JOIN AGENTE_DE_ALQUILER AG ON CL.ID_AGENTE_DE_ALQUILER = AG.ID_AGENTE_DE_ALQUILER\n"
                        + "INNER JOIN EMPLEADO E ON AG.ID_EMPLEADO = E.ID_EMPLEADO");
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    do {
                        tabla.addCell(rs.getString(1));
                        tabla.addCell(rs.getString(2));
                        tabla.addCell(rs.getString(3));
                        tabla.addCell(rs.getString(4));
                        tabla.addCell(rs.getString(5));
                        tabla.addCell(rs.getString(6));
                        tabla.addCell(rs.getString(7));
                    } while (rs.next());
                    documento.add(tabla);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e.toString());
            }
            documento.close();
            JOptionPane.showMessageDialog(null, "Reporte Creado");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EleccionAdmin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DocumentException ex) {
            Logger.getLogger(EleccionAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnReporteActionPerformed

    private void limpiar() {
        txtIdentidad.setText("");
        txtPrimerNombre.setText("");
        txtSegundoNombre.setText("");
        txtPrimerApellido.setText("");
        txtSegundoApellido.setText("");
        txtDireccion.setText("");
        txtEmail.setText("");
        txtTelefono.setText("");
        txtFecha.setText("");
        txtMarca.setText("");
        txtModelo.setText("");
        txtPrecio.setText("");
        btnGr.clearSelection();
    }

    private void cargarComboBoxSucursal() {
        PreparedStatement ps;
        ResultSet rs;
        try {
            Connection con = Conexion.getConexion();
            ps = con.prepareStatement("SELECT * FROM SUCURSAL");
            rs = ps.executeQuery();

            while (rs.next()) {
                cbSucursal.addItem(rs.getString(2));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }

    private void cargarComboBoxEmpleado() {
        PreparedStatement ps;
        ResultSet rs;
        try {
            Connection con = Conexion.getConexion();
            ps = con.prepareStatement("SELECT E.NOMBRE1\n"
                    + "FROM EMPLEADO E\n"
                    + "INNER JOIN AGENTE_DE_ALQUILER A ON E.ID_EMPLEADO = A.ID_EMPLEADO");
            rs = ps.executeQuery();

            while (rs.next()) {
                cbEmpleado.addItem(rs.getString(1));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cliente().setVisible(true);
            }
        });
    }

    private void cargarTablaAuto() {
        //con el DefaultTableModel le decimos que tome el diseño de la tabla que ya tenemos hecho
        DefaultTableModel modeloTabla = (DefaultTableModel) tblAutom.getModel();
        //esto sirve para que cada que se ejecute reinicie todas las tuplas y no se repita la info
        modeloTabla.setRowCount(0);

        PreparedStatement ps;
        ResultSet rs;
        ResultSetMetaData rsmd;
        int columnas;

        int[] anchos = {3, 50, 50, 10, 10, 10, 3};
        for (int i = 0; i < tblAutom.getColumnCount(); i++) {
            tblAutom.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        }

        try {
            Connection con = Conexion.getConexion();
            ps = con.prepareStatement("SELECT	ID_AUTOMOVIL,\n"
                    + "MARCA,\n"
                    + "MODELO,\n"
                    + "PASAJEROS,\n"
                    + "DISPONIBILIDAD,\n"
                    + "PRECIO\n"
                    + "FROM AUTOMOVIL");
            //Como no estamos enviando datos entonces para ejecutar ese tipo de consulta usamos 
            //executeQuery
            rs = ps.executeQuery();
            //el valor que arroje esa consulta lo guardamos en el ResultSet
            rsmd = rs.getMetaData();
            //el rs.getMetaData esto es para que nos traiga los metadatos de la consulta
            //y poder determinar abajo con columnas y saber cuantas columnas tiene
            columnas = rsmd.getColumnCount();
            while (rs.next()) {
                Object[] fila = new Object[columnas];
                for (int indice = 0; indice < columnas; indice++) {
                    fila[indice] = rs.getObject(indice + 1);
                }
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }

    private void cargarTabla() {
        //con el DefaultTableModel le decimos que tome el diseño de la tabla que ya tenemos hecho
        DefaultTableModel modeloTabla = (DefaultTableModel) tblCliente.getModel();
        //esto sirve para que cada que se ejecute reinicie todas las tuplas y no se repita la info
        modeloTabla.setRowCount(0);

        PreparedStatement ps;
        ResultSet rs;
        ResultSetMetaData rsmd;
        int columnas;

        int[] anchos = {3, 60, 75, 60, 60, 60, 3, 30, 80, 80, 17, 60, 60, 60, 40, 40};
        for (int i = 0; i < tblCliente.getColumnCount(); i++) {
            tblCliente.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        }

        try {
            Connection con = Conexion.getConexion();
            ps = con.prepareStatement("SELECT	CL.ID_CLIENTE,\n"
                    + "CL.IDENTIDAD,\n"
                    + "CL.NOMBRE1,\n"
                    + "CL.NOMBRE2,\n"
                    + "CL.APELLIDO1,\n"
                    + "CL.APELLIDO2,\n"
                    + "CL.SEXO,\n"
                    + "CL.DIRECCION,\n"
                    + "CL.EMAIL,\n"
                    + "CL.TELEFONO,\n"
                    + "CL.FECHA_ENTREGA_VEHICULO,\n"
                    + "S.NOMBRE,\n"
                    + "A.MARCA,\n"
                    + "A.MODELO,\n"
                    + "E.NOMBRE1\n"
                    + "FROM CLIENTE CL\n"
                    + "INNER JOIN SUCURSAL S ON S.ID_SUCURSAL = CL.ID_SUCURSAL\n"
                    + "INNER JOIN AUTOMOVIL A ON CL.ID_AUTOMOVIL = A.ID_AUTOMOVIL\n"
                    + "INNER JOIN AGENTE_DE_ALQUILER AG ON CL.ID_AGENTE_DE_ALQUILER = AG.ID_AGENTE_DE_ALQUILER\n"
                    + "INNER JOIN EMPLEADO E ON AG.ID_EMPLEADO = E.ID_EMPLEADO");
            //Como no estamos enviando datos entonces para ejecutar ese tipo de consulta usamos 
            //executeQuery
            rs = ps.executeQuery();
            //el valor que arroje esa consulta lo guardamos en el ResultSet
            rsmd = rs.getMetaData();
            //el rs.getMetaData esto es para que nos traiga los metadatos de la consulta
            //y poder determinar abajo con columnas y saber cuantas columnas tiene
            columnas = rsmd.getColumnCount();
            while (rs.next()) {
                Object[] fila = new Object[columnas];
                for (int indice = 0; indice < columnas; indice++) {
                    fila[indice] = rs.getObject(indice + 1);
                }
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnReporte;
    private javax.swing.JComboBox<String> cbEmpleado;
    private javax.swing.JComboBox<String> cbSucursal;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JRadioButton rbFemenino;
    private javax.swing.JRadioButton rbMasculino;
    private javax.swing.JTable tblAutom;
    private javax.swing.JTable tblCliente;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtDisponibilidad;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtIdentidad;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtModelo;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtPrimerApellido;
    private javax.swing.JTextField txtPrimerNombre;
    private javax.swing.JTextField txtSegundoApellido;
    private javax.swing.JTextField txtSegundoNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
