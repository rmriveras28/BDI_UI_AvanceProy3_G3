/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import Clases.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author kevin
 */
public class Factura extends javax.swing.JFrame {

    /**
     * Creates new form Factura
     */
    public Factura() {
        initComponents();
        this.setLocationRelativeTo(null);
        cargarTabla();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblFactura = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Facturas");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 11, -1, -1));

        tblFactura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Sucursal", "Nombre Empleado", "Apellido Empleado", "Voucher", "Nombre Cliente", "Apellido Cliente", "Marca Vehiculo", "Modelo Vehiculo", "Monto"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblFactura);
        if (tblFactura.getColumnModel().getColumnCount() > 0) {
            tblFactura.getColumnModel().getColumn(0).setResizable(false);
            tblFactura.getColumnModel().getColumn(1).setResizable(false);
            tblFactura.getColumnModel().getColumn(2).setResizable(false);
            tblFactura.getColumnModel().getColumn(3).setResizable(false);
            tblFactura.getColumnModel().getColumn(4).setResizable(false);
            tblFactura.getColumnModel().getColumn(5).setResizable(false);
            tblFactura.getColumnModel().getColumn(6).setResizable(false);
            tblFactura.getColumnModel().getColumn(7).setResizable(false);
            tblFactura.getColumnModel().getColumn(8).setResizable(false);
            tblFactura.getColumnModel().getColumn(9).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 972, 295));

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Transacciones");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(294, 372, -1, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setText("Clientes");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(563, 372, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/style.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 0, 690, 220));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/style.jpg"))); // NOI18N
        jLabel4.setText("jLabel2");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, 220));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/style.jpg"))); // NOI18N
        jLabel5.setText("jLabel2");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 700, 220));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/style.jpg"))); // NOI18N
        jLabel3.setText("jLabel2");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 100, 700, 360));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Transaccion t = new Transaccion();
        t.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Cliente c = new Cliente();
        c.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void cargarTabla() {
        //con el DefaultTableModel le decimos que tome el diseño de la tabla que ya tenemos hecho
        DefaultTableModel modeloTabla = (DefaultTableModel) tblFactura.getModel();
        //esto sirve para que cada que se ejecute reinicie todas las tuplas y no se repita la info
        modeloTabla.setRowCount(0);

        PreparedStatement ps;
        ResultSet rs;
        ResultSetMetaData rsmd;
        int columnas;

        int[] anchos = {3, 60, 60, 75, 60, 60, 50, 50, 60, 60};
        for (int i = 0; i < tblFactura.getColumnCount(); i++) {
            tblFactura.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        }

        try {
            Connection con = Conexion.getConexion();
            ps = con.prepareStatement("SELECT F.ID_FACTURA,\n"
                    + "S.NOMBRE,\n"
                    + "E.NOMBRE1,\n"
                    + "E.APELLIDO1,\n"
                    + "T.NUMERO_VOUCHER,\n"
                    + "CL.NOMBRE1,\n"
                    + "CL.APELLIDO1,\n"
                    + "A.MARCA,\n"
                    + "A.MODELO,\n"
                    + "A.PRECIO\n"
                    + "FROM FACTURA F\n"
                    + "INNER JOIN SUCURSAL S ON F.ID_SUCURSAL = S.ID_SUCURSAL\n"
                    + "INNER JOIN AGENTE_DE_ALQUILER AG ON F.ID_AGENTE_DE_ALQUILER = AG.ID_AGENTE_DE_ALQUILER\n"
                    + "INNER JOIN EMPLEADO E ON AG.ID_EMPLEADO = E.ID_EMPLEADO\n"
                    + "INNER JOIN TRANSACCION T ON F.ID_TRANSACCION = T.ID_TRANSACCION\n"
                    + "INNER JOIN CLIENTE CL ON F.ID_CLIENTE = CL.ID_CLIENTE\n"
                    + "INNER JOIN AUTOMOVIL A ON F.ID_AUTOMOVIL = A.ID_AUTOMOVIL");
            //Como no estamos enviando datos entonces para ejecutar ese tipo de consulta usamos 
            //executeQuery
            rs = ps.executeQuery();
            //el valor que arroje esa consulta lo guardamos en el ResultSet
            rsmd = rs.getMetaData();
            //el rs.getMetaData esto es para que nos traiga los metadatos de la consulta
            //y poder determinar abajo con columnas y saber cuantas columnas tiene
            columnas = rsmd.getColumnCount();
            while (rs.next()) {
                Object[] fila = new Object[columnas];
                for (int indice = 0; indice < columnas; indice++) {
                    fila[indice] = rs.getObject(indice + 1);
                }
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Factura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Factura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Factura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Factura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Factura().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblFactura;
    // End of variables declaration//GEN-END:variables
}
